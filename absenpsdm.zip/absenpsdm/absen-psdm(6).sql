-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 12, 2016 at 06:48 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `absen-psdm`
--

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `id` int(5) NOT NULL,
  `npm` varchar(8) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `jk` varchar(255) NOT NULL,
  `ttl` varchar(255) NOT NULL,
  `jurusan` varchar(255) NOT NULL,
  `domisili` varchar(255) NOT NULL,
  `angkatan` int(4) NOT NULL,
  `periode` varchar(10) NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `id_bidang` int(5) NOT NULL,
  `id_divisi` int(5) NOT NULL,
  `email` varchar(255) NOT NULL,
  `facebook` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `instagram` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id`, `npm`, `nama`, `jk`, `ttl`, `jurusan`, `domisili`, `angkatan`, `periode`, `jabatan`, `id_bidang`, `id_divisi`, `email`, `facebook`, `twitter`, `instagram`) VALUES
(1, '10114203', 'ade yusup permana', 'pria', 'ciamis , 28-06-1996', 'Sistem Informasi', 'Kalimalang', 2014, '2016-2017', 'Staff Biro PTI', 4, 1, 'adeyusupp@gmail.com', '-', '-', '-'),
(4, '10114206', 'deni', 'pria', 'bekasi , 28-06-1996', 'Sistem Informasi', 'Kalimalang', 2014, '2016-2017', 'Staff Biro PTI', 4, 1, 'adeyusupp@gmail.com', '-', '-', '-'),
(5, '10114207', 'bachtiar', 'pria', 'bekasi , 28-06-1996', 'Sistem Informasi', 'Kalimalang', 2014, '2016-2017', 'Staff Biro PTI', 4, 2, 'adeyusupp@gmail.com', '-', '-', '-'),
(6, '10114209', 'delonix', 'pria', 'bekasi , 28-06-1996', 'Sistem Informasi', 'Kalimalang', 2014, '2016-2017', 'Staff Dep PSDM', 1, 10, 'adeyusupp@gmail.com', '-', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

CREATE TABLE `bidang` (
  `id_bidang` int(5) NOT NULL,
  `nama_bidang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`id_bidang`, `nama_bidang`) VALUES
(1, 'Bidang 1'),
(2, 'Bidang 2'),
(3, 'Bidang 3'),
(4, 'Bidang 4');

-- --------------------------------------------------------

--
-- Table structure for table `divisi`
--

CREATE TABLE `divisi` (
  `id_divisi` int(5) NOT NULL,
  `nama_divisi` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `divisi`
--

INSERT INTO `divisi` (`id_divisi`, `nama_divisi`) VALUES
(1, 'Biro Pengembangan Teknologi & Informasi'),
(2, 'Biro Media'),
(3, 'Biro Hubungan Masyarakat'),
(4, 'Departemen Seni Budaya'),
(5, 'Departemen Olahraga'),
(6, 'Departemen Kewirausahaan'),
(7, 'Departemen Pengabdian Masyarakat'),
(8, 'Departemen Kesejahteraan Mahasiswa'),
(9, 'Departemen Akademik'),
(10, 'Departemen Pengembangan Sumber Daya Masyarakat');

-- --------------------------------------------------------

--
-- Table structure for table `psdm_absen`
--

CREATE TABLE `psdm_absen` (
  `id_absen` int(5) NOT NULL,
  `id_rapat` int(5) NOT NULL,
  `npm` varchar(8) NOT NULL,
  `jml_hdr` int(5) NOT NULL,
  `jml_tdkhdr` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `psdm_keterangan`
--

CREATE TABLE `psdm_keterangan` (
  `id_ket` int(5) NOT NULL,
  `id_rapat` int(5) NOT NULL,
  `npm` varchar(8) NOT NULL,
  `tgl` varchar(255) NOT NULL,
  `ket` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `psdm_koordinator`
--

CREATE TABLE `psdm_koordinator` (
  `id_koor` int(5) NOT NULL,
  `nama_koor` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `psdm_koordinator`
--

INSERT INTO `psdm_koordinator` (`id_koor`, `nama_koor`, `username`, `password`) VALUES
(4, 'delonix', 'delonix', 'delonix');

-- --------------------------------------------------------

--
-- Table structure for table `psdm_rapat`
--

CREATE TABLE `psdm_rapat` (
  `id_rapat` int(5) NOT NULL,
  `nama_rapat` varchar(255) NOT NULL,
  `id_koor` int(5) NOT NULL,
  `stat` int(5) NOT NULL,
  `jml_rapat` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `psdm_rekap_bulanan`
--

CREATE TABLE `psdm_rekap_bulanan` (
  `no` int(5) NOT NULL,
  `npm` varchar(8) NOT NULL,
  `bulan` varchar(255) NOT NULL,
  `jml_hdr` int(5) NOT NULL,
  `jml_tdkhdr` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `psdm_rekap_tahunan`
--

CREATE TABLE `psdm_rekap_tahunan` (
  `no` int(5) NOT NULL,
  `npm` varchar(8) NOT NULL,
  `tahun` varchar(255) NOT NULL,
  `jml_hdr` int(5) NOT NULL,
  `jml_tdkhdr` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(5) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`) VALUES
(1, 'psdm', 'psdm', 'wew');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bidang`
--
ALTER TABLE `bidang`
  ADD PRIMARY KEY (`id_bidang`);

--
-- Indexes for table `divisi`
--
ALTER TABLE `divisi`
  ADD PRIMARY KEY (`id_divisi`);

--
-- Indexes for table `psdm_absen`
--
ALTER TABLE `psdm_absen`
  ADD PRIMARY KEY (`id_absen`);

--
-- Indexes for table `psdm_keterangan`
--
ALTER TABLE `psdm_keterangan`
  ADD PRIMARY KEY (`id_ket`);

--
-- Indexes for table `psdm_koordinator`
--
ALTER TABLE `psdm_koordinator`
  ADD PRIMARY KEY (`id_koor`);

--
-- Indexes for table `psdm_rapat`
--
ALTER TABLE `psdm_rapat`
  ADD PRIMARY KEY (`id_rapat`);

--
-- Indexes for table `psdm_rekap_bulanan`
--
ALTER TABLE `psdm_rekap_bulanan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `psdm_rekap_tahunan`
--
ALTER TABLE `psdm_rekap_tahunan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `bidang`
--
ALTER TABLE `bidang`
  MODIFY `id_bidang` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `divisi`
--
ALTER TABLE `divisi`
  MODIFY `id_divisi` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `psdm_absen`
--
ALTER TABLE `psdm_absen`
  MODIFY `id_absen` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
--
-- AUTO_INCREMENT for table `psdm_keterangan`
--
ALTER TABLE `psdm_keterangan`
  MODIFY `id_ket` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `psdm_koordinator`
--
ALTER TABLE `psdm_koordinator`
  MODIFY `id_koor` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `psdm_rapat`
--
ALTER TABLE `psdm_rapat`
  MODIFY `id_rapat` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `psdm_rekap_bulanan`
--
ALTER TABLE `psdm_rekap_bulanan`
  MODIFY `no` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `psdm_rekap_tahunan`
--
ALTER TABLE `psdm_rekap_tahunan`
  MODIFY `no` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
