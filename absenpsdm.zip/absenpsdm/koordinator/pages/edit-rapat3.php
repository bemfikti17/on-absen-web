<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Departemen/Biro</th>
				<th>Option</th>
			</tr>
		</thead>
		<tbody>	
<?php 
$no=1;
$query2=mysql_query("SELECT * FROM psdm_absen,anggota,divisi where (anggota.id_divisi=divisi.id_divisi) AND (psdm_absen.npm=anggota.npm) AND (id_rapat='{$_GET['id']}')");
while ($row2=mysql_fetch_array($query2)) {
	echo '
			<tr>
				<td>'.$no++.'</td>
				<td>'.$row2['nama'].'</td>
				<td>'.$row2['nama_divisi'].'</td>
				<td align="center"><a class="btn btn-danger btn-xs" href="javascript:delete_id('.$row2['npm'].');"><i class="fa fa-times fa-fw""></i>hapus</a></td>

			</tr>	
	';
}
 ?>
 </tbody>
 </table>