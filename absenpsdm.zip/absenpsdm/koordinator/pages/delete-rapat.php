<?php
include "session.php";

$id=$_GET['id'];
//hapus rapat dari tabel psdm_rapat
$sql="DELETE FROM psdm_rapat WHERE id_rapat='$id'";
$query=mysql_query($sql);

//hapus data anggota yang mengikuti rapat
$sql2="DELETE FROM psdm_presensi WHERE id_rapat='$id'";
$query=mysql_query($sql2);

//hapus data anggota yang mengikuti rapat
$sql3="DELETE FROM psdm_keterangan WHERE id_rapat='$id'";
$query=mysql_query($sql3);

		if($query){
				echo '<script language="javascript">alert("Data Berhasil Dihapus"); document.location="index.php";</script>';
			}
			else{
				echo '<script language="javascript">alert("Data Gagal Dihapus"); document.location="javascript:history.go(-1)";</script>';

			}

header('Location: index.php');
?>