<?php 
require_once '../../config/koneksi.php';

if(isset($_POST['simpan'])){
		$nama_rapat = $_POST['nama_rapat'];

		$result = mysql_query("SELECT * FROM psdm_rapat WHERE nama_rapat='".$nama_rapat."'");
		if(mysql_num_rows($result)==0){
				$query = mysql_query("INSERT INTO psdm_rapat VALUES ('','$nama_rapat', '$id_koor','0','0')")or die(mysql_error());
		
			if($query){
				echo '<script language="javascript">alert("Data Berhasil Disimpan"); document.location="index.php";</script>';
			}
			else{
				echo '<script language="javascript">alert("Data Gagal Disimpan"); document.location="index.php";</script>';

			}
		}
		else{
			echo '<script language="javascript">alert("Nama Rapat Sudah Ada !!"); document.location="index.php";</script>';
		}
}
?>

<form action="" method="POST">
	<p>Nama Rapat : <input type="text" name="nama_rapat" required></p><br>
	<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="simpan" value="Simpan" class="btn btn-primary"> 
    </div>
</form>