<?php
include 'session.php';

$npm=$_GET['npm'];
//hapus rapat dari tabel psdm_rapat
$sql="DELETE FROM psdm_absen WHERE npm='$npm'";
$query=mysql_query($sql);

//hapus data anggota yang mengikuti rapat
$sql2="DELETE FROM psdm_keterangan WHERE npm='$npm'";
$query=mysql_query($sql2);

echo '<script language="javascript">document.location="javascript:history.go(-1)";</script>';
?>