<?php 
include "session.php";

if (isset($_POST['batal'])) {
		header("Location: index.php"); 
	}
	
	elseif(isset($_POST['simpan'])){
		$nama_rapat = $_POST['nama_rapat'];
		$id = $_POST['id'];

		$result = mysql_query("SELECT * FROM psdm_rapat WHERE nama_rapat='".$nama_rapat."'");
		if(mysql_num_rows($result)==0){
			$sql="UPDATE psdm_rapat SET nama_rapat = '$nama_rapat' WHERE id_rapat = '$id'";
			$query = mysql_query($sql);
			if($query){
				echo '<script language="javascript">alert("Data Berhasil Disimpan"); document.location="index.php";</script>';
			}
			else{
				echo '<script language="javascript">alert("Data Gagal Disimpan"); document.location="edit-rapat.php";</script>';

			}
		}
		else{
			echo '<script language="javascript">alert("Nama Rapat Sudah Ada !!"); document.location="javascript:history.go(-1)";</script>';
		}
	}


$query = mysql_query("SELECT * FROM psdm_rapat WHERE id_rapat = '{$_GET['id']}'");
$row = mysql_fetch_array($query);
?>
<form action="" method="POST">
	<label>Nama Rapat : </label>
	<input type="text" name="nama_rapat" value="<?php echo $row['nama_rapat'];  ?>" class="form-control"></p><br>
	<input type="hidden" name="id" value="<?php echo $row['id_rapat'];  ?>">
	
	<p><input type="submit" name="simpan" value="Simpan" class="btn btn-primary"> <input type="submit" name="batal" value="Batal" class="btn btn-danger"></p>
</form>
	