<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<?php
include "session.php";


if(isset($_POST['simpan'])){    
$cnt = count($_POST['absen']);
$idrapat = $_POST['rapat'];
$tgl = date("d/m/Y");
for($i=0;$i<$cnt;$i++){   
    $absen = $_POST['absen'][$i]; 
    $ket   = $_POST['ket'][$i];
    $id = $_POST['id_absen'][$i];
    $npm = $_POST['npm'][$i];
    if($absen == "masuk"){
        $sql=mysql_query("INSERT INTO psdm_presensi (id_presensi, id_rapat, npm, hadir, tdk_hdr, tgl)
            VALUES ('',
                    '$idrapat',
                    '$npm',
                    '1',
                    '0',
                    '$tgl')") or die(mysql_error());
    }
    else{
        $sql=mysql_query("INSERT INTO psdm_presensi (id_presensi, id_rapat, npm, hadir, tdk_hdr, tgl)
            VALUES ('',
                    '$idrapat',
                    '$npm',
                    '0',
                    '1',
                    '$tgl')") or die(mysql_error());
        $query1=mysql_query("INSERT INTO psdm_keterangan (id_ket, id_rapat, npm, tgl, ket)
                values('',
                       '$idrapat',
                       '$npm',
                       '$tgl',
                       '$ket')") or die(mysql_error());

    }
        }
    $sql3=mysql_query("UPDATE psdm_rapat SET jml_rapat=jml_rapat+1 WHERE id_rapat = '$idrapat'");
    $query = mysql_query($sql3); 

        if(!$query){
                echo '<script language="javascript">alert("Data Berhasil Disimpan"); document.location="index.php";</script>';
            }/*
            else{
                echo '<script language="javascript">alert("Data Gagal Disimpan"); document.location="javascript:history.go(-1)";</script>';

            }*/
}
?>

<form action="" method="post">
<?php
    $query2 = "SELECT * FROM psdm_rapat WHERE id_rapat = '{$_GET['id']}'";
    $result = mysql_query($query2);
    while($row=mysql_fetch_array($result, MYSQL_ASSOC)){
        $nama_rapat = $row['nama_rapat'];
       echo '<input type="hidden" name="rapat" value="'.$row['id_rapat'].'">';
    }
    echo '
    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Jabatan</th>
            <th>Departemen/Biro</th>
            <th>Keterangan</th>
        </tr>
    </thead>
    <tbody>
    ';
    $no = 1;
    $query3 = "SELECT * FROM anggota, psdm_absen, divisi WHERE (anggota.npm=psdm_absen.npm) AND (anggota.id_divisi=divisi.id_divisi) AND (psdm_absen.id_rapat='$_GET[id]') ORDER BY anggota.nama asc";
    $result2 = mysql_query($query3);
    while($row2=mysql_fetch_array($result2, MYSQL_ASSOC)){
        $tmp1 = $no;
        ?>
<script type="text/javascript">
    jQuery(document).ready(function(){
        $('#masuk-<?php echo "$tmp1"; ?>').live('click', function(event) {        
        $('#ket-<?php echo "$tmp1"; ?>').hide("slow");
        $('#ket-<?php echo "$tmp1"; ?>').val("");
    });
    jQuery('#tidak-<?php echo "$tmp1"; ?>').live('click', function(event) {        
        $('#ket-<?php echo "$tmp1"; ?>').show("slow");
        $('#ket-<?php echo "$tmp1"; ?>').val("");
    });
});
</script>
        <?php
        echo '
        <tr>
            <td> '.$no++.' 
                <input type="hidden" name="id_absen[]" value="'.$row2['id_absen'].'" />
                <input type="hidden" name="npm[]" value="'.$row2['npm'].'" />
            </td>
            <td> '.$row2['nama'].' </td>
            <td> '.$row2['jabatan'].' </td>
            <td> '.$row2['nama_divisi'].' </td>
            <td align="center">
                <select name="absen[]" id="combo" class="form-control">
                    <option id="masuk-'.$tmp1.'" value="masuk">Masuk</option>
                    <option id="tidak-'.$tmp1.'" value="tdk_masuk">Tidak Masuk</option>
                </select><br/>
                <input name="ket[]" type="text" id ="ket-'.$tmp1.'" value="" placeholder="Isi keterangan Disini" style="display:none; width: 200px; margin-top: 5px;"/>
            </td>
        </tr>
        ';
        ?>
<?php
}
    echo '
    </tbody>
    </table>';
?>
<input class="btn btn-primary" type="submit" name="simpan" value="Simpan" onclick="return confirm('Anda yakin seluruh data sudah benar??')">
<a href="index.php" class="btn btn-danger">Batal</a>

</form>
</body>
</html>