<?php 
session_start();
require_once '../../config/koneksi.php';
$username = $_SESSION['username'];
if (isset($username)) {
	$result = mysql_query("SELECT * FROM psdm_koordinator where username='$username'");
	
		while($row = mysql_fetch_array($result)){	
			$id_koor = $row['id_koor'];
		}
}		
else {
	header("Location: login.php");
}

?>