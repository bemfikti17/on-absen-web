
<?php
include "session.php";

if(isset($_POST['simpan'])){
$cnt = count($_POST['agt']);
$id_rapat = $_POST['rapat'];
for($i=0;$i<$cnt;$i++){
    $npm   = $_POST['agt'][$i];
    $result3 = mysql_query("SELECT * FROM psdm_absen WHERE (id_rapat = '$id_rapat') AND (npm='$npm')");
    $row = mysql_fetch_array($result3);
    $npm2 = $row['npm']; 
    if($npm == $npm2){
    ?>
    <script language="javascript">
            alert("                                 Data Gagal Disimpan!!\n\n*Beberapa data yang anda masukan sudah ada didalam database");
            document.location="javascript:history.go(-1)";
    </script>
    <?php
    die();
    } 
}
$id_rapat = $_POST['rapat'];
$jml_hdr = '0';
$jml_tdkhdr = '0';
$sql=mysql_query("UPDATE psdm_rapat SET stat = 1 WHERE id_rapat = '$id_rapat'");
$query3 = mysql_query($sql);
for($i=0;$i<$cnt;$i++){
    $npm   = $_POST['agt'][$i];
	$query=mysql_query("INSERT INTO psdm_absen (id_absen, id_rapat, npm, jml_hdr, jml_tdkhdr)
				values('',
				'$id_rapat',
				'$npm',
				'$jml_hdr',
				'$jml_tdkhdr'
				)");
        }
		if($query){
				echo '<script language="javascript">alert("Data Berhasil Disimpan"); document.location="index.php";</script>';
			}
			else{
				echo '<script language="javascript">alert("Data Gagal Disimpan"); document.location="javascript:history.go(-1)";</script>';

			}
    
}

?>

<form action="" method="post">
<?php
    $query2 = "SELECT * FROM psdm_rapat WHERE id_rapat = '{$_GET['id']}'";
    $result = mysql_query($query2);
    while($row=mysql_fetch_array($result, MYSQL_ASSOC)){
       echo '<input type="hidden" name="rapat" value="'.$row['id_rapat'].'">';
    }
    echo '
    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
        	<tr>
        		<th>No</th>
        		<th>Nama</th>
        		<th>Departemen/Biro</th>
        		<th>Option</th>
    		</tr>
        </thead>
        <tbody>
    ';
    $no = 1;
    $query3 = "SELECT * FROM anggota, divisi WHERE (anggota.id_divisi=divisi.id_divisi) ORDER BY anggota.nama asc";
    $result2 = mysql_query($query3);

    while($row2=mysql_fetch_array($result2, MYSQL_ASSOC)){ 
        $tmp1 = $no;
        $nama2 = $row2['nama'];
        echo '
        	<tr>
        		<td> '.$no++.' </td>
        		<td> '.$row2['nama'].'</td>
                <td> '.$row2['nama_divisi'].'</td>
        		<td><input class="cb1-'.$tmp1.'" type="checkbox" name="agt[]" value="'.$row2['npm'].'"> Masukan</td>
    		</tr>
    	';	
    }
echo '
</tbody>
</table>
<input class="btn btn-primary" type="submit" name="simpan" value="Simpan">
<a href="index.php" class="btn btn-danger">Batal</a>
</form>
';
?>

