<?php 
include 'session.php';
 ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Absen Online</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="../vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><img src="../img/logo.png" style="height:70px; margin-top: -14px;"></a>

            </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <a href="logout.php" style="height: 70px; padding-top:25px"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                </li>
            </ul>

            
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header"><?php echo 'Selamat Datang Koordinator '.$username.''; ?></h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                <i class="fa fa-plus fa-fw"></i> Tambah Rapat
                </button><br><br>
                            <!-- Modal -->
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Tambah Rapat</h4>
                                        </div>
                                        <div class="modal-body">
                                            <?php include "tambah-rapat2.php"; ?>
                                        </div>

                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
                            <!-- /.modal -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           <strong><i class="fa fa-th-list fa-fw"></i> List Rapat Untuk Anda</strong>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Rapat</th>
                                        <th>Status Anggota</th>
                                        <th>Telah Terlaksana Sebanyak</th>
                                        <th>Option</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $result = mysql_query("SELECT * FROM psdm_rapat WHERE id_koor LIKE $id_koor");
                                $no=1;
                                $total_row = mysql_num_rows($result);
                                if ($total_row > 0) {
                                while($row = mysql_fetch_array($result)){   
                                    
                                    $id_rapat = $row['id_rapat'];
                                    $nama_rapat = $row['nama_rapat'];
                                    $stat = $row['stat'];
                                    $jml_rapat = $row['jml_rapat'];
                                    if ($stat == 0){
                                        $status = "Tidak Ada";
                                    }
                                    else{
                                        $status = "Sudah Ada";
                                    }
                                    echo '
                                    
                                        <tr>
                                            <td>' . $no++ . ' </td>
                                            <td>' . $nama_rapat . '</td>
                                            <td>' . $status . '</td>
                                            <td>' . $jml_rapat . ' kali</td>
                                            <td> 
                                                <a class="btn btn-primary btn-xs" href="anggota.php?id=' . $id_rapat . '"><i class="fa fa-plus fa-fw"></i>Tambah Anggota </a>
                                                <a class="btn btn-success btn-xs" href="absen.php?id=' . $id_rapat . '"><i class="fa fa-check-square-o fa-fw"></i> Absen </a>
                                                <a class="btn btn-warning btn-xs" href="edit-rapat.php?id=' . $id_rapat . '"><i class="fa fa-pencil fa-fw"></i> Edit </a>
                                                <a class="btn btn-danger btn-xs" href="javascript:delete_id('.$id_rapat.')"><i class="fa fa-times fa-fw"></i> Delete</a>
                                            </td>
                                        </tr> 
                                    
                                     ';
                                    }
                                }else{  
                                    echo '
                                        <tr class="odd gradeX">
                                            <td colspan="5">Tidak Ada Data</td>
                                        </tr>    
                                        ';
                                }
                                 ?>
                                </tbody> 
                            </table>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
    <script type="text/javascript">
    function delete_id(id){
     if(confirm('Apakah anda yakin menghapus data ini ?')){
        window.location.href='delete-rapat.php?id='+id;
        }
    }
    </script>

</body>

</html>
