<?php 
include 'session.php';
	
	echo "<h1> List Rapat untuk koordinator $username </h1>";

	$result = mysql_query("SELECT * FROM psdm_rapat WHERE id_koor LIKE $id_koor");

		echo '
				<a href="tambah-rapat.php">Tambah Rapat</a> <br><br>
				<table border="1">
					<tr>	
						<td>No </td>
						<td>Nama Rapat </td>
						<td>Status Anggota</td>
						<td>Option </td>
					</tr>
		';
		$no=1;
		while($row = mysql_fetch_array($result)){	
			
			$id_rapat = $row['id_rapat'];
			$nama_rapat = $row['nama_rapat'];
			$stat = $row['stat'];
			if ($stat == 0){
				$status = "Tidak Ada";
			}
			else{
				$status = "Sudah Ada";
			}
			echo '
					
						<tr>
							<td>' . $no++ . ' </td>
							<td>' . $nama_rapat . '</td>
							<td>' . $status . '</td>
							<td> 
								<a href="anggota.php?id=' . $id_rapat . '"> Tambah Anggota </a> |
								<a href="absen.php?id=' . $id_rapat . '"> Absen </a> |  
								<a href="edit-rapat.php?id=' . $id_rapat . '"> Edit </a> |
								<a href="delete-rapat.php?id=' . $id_rapat . '"> Delete </a>
						</tr>	
			';
		}
		echo '</table>';
	

?>