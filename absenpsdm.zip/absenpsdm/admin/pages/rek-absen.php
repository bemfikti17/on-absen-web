<?php 
include 'sessions.php';
	
	echo "<h1> List Anggota  </h1>";

	$result = mysql_query("SELECT * FROM anggota, divisi WHERE (anggota.id_divisi=divisi.id_divisi)");

		echo '
				<table border="1">
					<tr>	
						<td>No </td>
						<td>Nama </td>
						<td>Jabatan</td>
						<td>Dep/Bir</td>
						<td>Option </td>
					</tr>
		';
		$no=1;
		while($row = mysql_fetch_array($result)){	
			
			$npm = $row['npm'];
			$nama = $row['nama'];
			$jabatan = $row['jabatan'];
			$divisi = $row['nama_divisi'];
			echo '
					
						<tr>
							<td>' . $no++ . ' </td>
							<td>' . $nama . '</td>
							<td>' . $jabatan . '</td>
							<td>' . $divisi . '</td>
							<td> 
								<a href="detail-absen.php?npm=' . $npm . '"> Detail </a> 								
						</tr>	
			';
		}
		echo '</table>';
	

?>