<?php 
$id_rapat = $_GET['id'];
$query=mysql_query("SELECT nama_rapat FROM psdm_rapat WHERE id_rapat='$id_rapat'");
while($row=mysql_fetch_array($query)){
	$nama_rapat=$row['nama_rapat'];
}
echo '
 	<div class="col-lg-12">
 	<a href="rek-rapat.php"><i class="fa fa-arrow-left fa-fw"></i> Back</a><br><br>
        <div class="panel panel-default">                    
            <div class="panel-heading">                        
                <i class="fa fa-calendar fa-fw"></i><strong> Tanggal</strong>
            </div>
            <!-- /.panel-heading -->
                <div class="panel-body">                                                      
					<form action="" method="POST">
						<p>Nama Rapat : '.$nama_rapat.'</p>
						<select name="tgl" id="combo" class="form-control">
							<option value="">-- Pilih Tanggal --</option>
';
					$query=mysql_query("SELECT tgl FROM psdm_presensi WHERE id_rapat='$id_rapat' GROUP BY tgl");
					while($row=mysql_fetch_array($query)){
						$tgl = $row['tgl'];
						echo '
							<option value="'.$tgl.'">'.$tgl.'</option>
						';
					}
					echo '
						</select><br>
						<input class="btn btn-primary" type="submit" name="enter" value="ENTER"><br><br>
					</form>
					<!-- /.Form -->
                </div>
                <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
';


if (isset($_POST['enter'])) {
$tgl2 =$_POST['tgl'];
echo '
	<div class="col-lg-12">
        <div class="panel panel-default">                    
            <div class="panel-heading">                        
                <i class="fa fa-th-list fa-fw"></i><strong> Hasil Rapat Pada Tanggal : '.$tgl2.'</strong>
            </div>
            <!-- /.panel-heading -->
                <div class="panel-body">                                                      
';		
		$query=mysql_query("SELECT * FROM psdm_presensi, anggota, divisi WHERE (psdm_presensi.npm=anggota.npm) and (psdm_presensi.id_rapat='$id_rapat') and (anggota.id_divisi=divisi.id_divisi) and (psdm_presensi.tgl='$tgl2') ORDER BY anggota.nama asc");
		$query2=mysql_query("SELECT * FROM psdm_keterangan WHERE (id_rapat='$id_rapat') and (tgl='$tgl2')");
		echo '
				<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example"><thead>
						<tr>
							<th rowspan="2">No</th>
							<th rowspan="2">Nama</th>
							<th rowspan="2">Jabatan</th>
							<th rowspan="2">Departermen/Biro</th>
							<td colspan="2" align="center"><strong>Keterangan</strong></td>
						</tr>
						<tr>
							<th>Kehadiran</th>
							<th>Alasan</th>
						</tr>
					</thead>
					<tbody>
		';
		$no=1;
		$row2=mysql_fetch_array($query2);
		while($row=mysql_fetch_array($query)){
			$ket=$row['hadir'];
			$npm=$row['npm'];
			$npm2=$row2['npm'];
			if($ket == 1){
				$aw='<i class="fa fa-check fa-fw" style="color :#449D44;"></i>';
				$lol="-";
			}else{
				$aw='<i class="fa fa-times fa-fw" style="color :#C9302C;"></i>';
				if($npm == $npm2){
					$lol=$row2['ket'];
				}

			}
			echo '
						<tr>
							<td>'.$no++.'</td>
							<td>'.$row['nama'].'</td>
							<td>'.$row['jabatan'].'</td>
							<td>'.$row['nama_divisi'].'</td>
							<td align="center">'.$aw.'</td>
							<td align="center">'.$lol.'</td>
						</tr>

			';
		}
		echo '
				</tbody>
				</table>
				</div>
                <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>			
		';
	}
?>