<?php 

	$result = mysql_query("SELECT * FROM psdm_absen , psdm_rapat, psdm_koordinator WHERE (psdm_absen.id_rapat = psdm_rapat.id_rapat) AND (psdm_rapat.id_koor = psdm_koordinator.id_koor) GROUP BY psdm_absen.id_rapat");

		echo '
			<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr>	
						<th>No</th>
						<th>Nama Rapat</th>
						<th>Koordinator</th>
						<th>Telah Terlaksana</th>
						<th>Option</th>
					</tr>
				</thead>
				<tbody>	
		';
		$no=1;
		while($row = mysql_fetch_array($result)){	
			$id_rapat=$row['id_rapat'];
			$koor=$row['nama_koor'];
			$jml_rapat=$row['jml_rapat'];
			$nama_rapat=$row['nama_rapat'];
			echo '
					<tr>
						<td>' . $no++ . '</td>
						<td>' . $nama_rapat . '</td>
						<td>' . $koor . '</td>
						<td>' . $jml_rapat . ' kali</td>
						<td><a href="det-rapat.php?id='.$id_rapat.'">detail</a></td>
					</tr>	
			';
		}
		echo '
				</tbody>
			</table>

			';
 ?>