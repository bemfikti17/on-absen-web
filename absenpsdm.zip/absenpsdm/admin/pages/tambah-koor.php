<?php 
include '../../config/koneksi.php';
if (isset($_POST['batal'])) {
		header("Location: koor.php"); 
	}
	
	elseif(isset($_POST['simpan'])){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$nama = $_POST['nama'];

		$result = mysql_query("SELECT * FROM psdm_koordinator WHERE username='".$username."'");
		if(mysql_num_rows($result)==0){
				$query = mysql_query("INSERT INTO psdm_koordinator VALUES ('','$nama', '$username','$password')")or die(mysql_error());
		
			if($query){
				echo '<script language="javascript">alert("Data Berhasil Disimpan"); document.location="koor.php";</script>';
			}
			else{
				echo '<script language="javascript">alert("Data Gagal Disimpan"); document.location="tambah-koor.php";</script>';

			}
		}
		else{
			echo '<script language="javascript">alert("Username Sudah ada!!"); document.location="koor.php";</script>';
		}
}
?>

<form action="" method="POST">
	<div class="form-group">
		<input nput class="form-control" type="text" name="username" placeholder="Username">
	</div>
	<div class="form-group">
		<input nput class="form-control" type="password" name="password" placeholder="Password">
	</div>
	<div class="form-group">
		<input nput class="form-control" type="text" name="nama" placeholder="Nama Koordinator">
	</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
    </div>
</form>