<?php 

if (isset($_POST['batal'])) {
		header("Location: edit-koor.php"); 
	}
	
	elseif(isset($_POST['simpan'])){
		$password = $_POST['password'];
		$nama = $_POST['nama'];
		$id = $_POST['id'];

			$sql="UPDATE psdm_koordinator SET nama_koor = '$nama', password = '$password'  WHERE id_koor = '$id'";
			$query = mysql_query($sql);
			if($query){
				echo '<script language="javascript">alert("Data Berhasil Disimpan"); document.location="koor.php";</script>';
			}
			else{
				echo '<script language="javascript">alert("Data Gagal Disimpan"); document.location="edit-koor.php";</script>';

			}
		}
$query = mysql_query("SELECT * FROM psdm_koordinator WHERE id_koor = '{$_GET['id']}'");
$row = mysql_fetch_array($query);
?>
<form action="" method="POST">
	<div class="form-group">
		<label>Username</label>
		<input type="hidden" name="id" value="<?php echo $row['id_koor'];  ?>">
		<input type="text" name="username" class="form-control" id="disabledInput" value="<?php echo $row['username'];  ?>" disabled>
	</div>
	<div class="form-group">
		<label>Password</label>
		<input type="password" name="password" class="form-control" value="<?php echo $row['password']; ?>">
	</div>
	<div class="form-group">
		<label>Nama Koordinator</label> 
		<input type="text" name="nama" class="form-control" value="<?php echo $row['nama_koor']; ?>">
	</div>
	<input class="btn btn-primary" type="submit" name="simpan" value="Simpan">   
	<a class="btn btn-danger" href="koor.php">Batal</a></p>
</form>