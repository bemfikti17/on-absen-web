<?php 
session_start();
require_once '../../config/koneksi.php';
$usernama = $_SESSION['usernama'];
if (isset($usernama)) {
	$result = mysql_query("SELECT * FROM psdm_koordinator where username='$usernama'");
	
		while($row = mysql_fetch_array($result)){	
			$id_koor = $row['id_koor'];
		}
}		
else {
	header("Location: login.php");
}

?>