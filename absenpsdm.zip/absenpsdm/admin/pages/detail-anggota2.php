<?php 
$npm = $_GET['npm'];
$result = mysql_query("SELECT * FROM anggota, divisi WHERE (anggota.id_divisi=divisi.id_divisi) AND (anggota.npm='$npm')");
$row = mysql_fetch_array($result);
$nama = $row['nama'];
$jabatan = $row['jabatan'];
$divisi = $row['nama_divisi'];

	//menghitung persentasi kehadiran anggota
	$b=0;
	$d=0;
	$e=0;
    $query3 = "SELECT psdm_presensi.npm, sum(psdm_presensi.hadir), psdm_rapat.jml_rapat FROM psdm_presensi, psdm_rapat, psdm_koordinator WHERE (psdm_rapat.id_koor=psdm_koordinator.id_koor) AND (psdm_presensi.id_rapat=psdm_rapat.id_rapat) AND (psdm_presensi.npm = '$npm') group by psdm_presensi.id_rapat;";
    $result3 = mysql_query($query3);
    while($row3=mysql_fetch_array($result3, MYSQL_ASSOC)){
    	//bahan untuk menghitung persentase kehadiran anggota
    	$a=$row3['sum(psdm_presensi.hadir)'];
    	//b = varibel untuk menyimpan jumlah kehadiran anggota
    	$b+=$a;
    	$c=$row3['jml_rapat'];
    	//d = variabel untuk menyimpan jumlah rapat yang telah terlaksana
    	$d+=$c;
	    }

	if($d==0){
	$e=0;
	}else{
	$e=((100*$b)/$d);
	}
echo '
<div class="col-md-8">
<strong><br><br>
	<table style="font-size: 16px;">
		<tr>
			<td>Nama</td>
			<td>&nbsp; : &nbsp;</td>
			<td>'.$nama.'</td>
		</tr>
		<tr>
			<td>Jabatan</td>
			<td>&nbsp; : &nbsp;</td>
			<td>'.$jabatan.'</td>
		</tr>
		<tr>
			<td>Departemen/Biro</td>
			<td>&nbsp; : &nbsp;</td>
			<td>'.$divisi.'</td>
		</tr>
	</table>
</div>
<div class="col-md-4">
	<div class="panel panel-default">                    
        <div class="panel-heading">                        
            </i><strong><center>Persentase Kehadiran</center></strong>
        </div>
        <div class="panel-body">
        ';
        settype($e, "integer");
        echo'
            <h2 align="center">'.$e.'%</h2>                                        
        </div>                    
    </div>
</div>
<div class="col-lg-12">	
</strong>			
	<hr><h3>Semua Rapat</h3><br>

';

	echo '	
			<table width="100%" class="table table-striped table-bordered table-hover" id="daataTables-example">
				<thead>
					<tr>
						<th>No</th>
						<th>Nama Rapat</th>
						<th>Nama Koordinator</th>
						<th>Jumlah Hadir</th>
						<th>Jumlah Tidak Hadir</th>
					</tr>
				</thead>
				<tbody>		
	';	
	$no = 1;
	$b=0;
	$d=0;
	$e=0;
    $query2 = "SELECT psdm_rapat.nama_rapat, psdm_koordinator.nama_koor, sum(hadir), sum(tdk_hdr) FROM psdm_presensi, psdm_rapat, psdm_koordinator WHERE (psdm_rapat.id_koor=psdm_koordinator.id_koor) AND (psdm_presensi.id_rapat=psdm_rapat.id_rapat) AND (psdm_presensi.npm = '$npm') group by psdm_rapat.nama_rapat;
";
    $result2 = mysql_query($query2);
    $total_row = mysql_num_rows($result2);
	if ($total_row > 0) {
    while($row2=mysql_fetch_array($result2, MYSQL_ASSOC)){
    	echo '
    			<tr>
    				<td>'.$no++.'</td>
    				<td>'.$row2['nama_rapat'].'</td>
    				<td>'.$row2['nama_koor'].'</td>
    				<td>'.$row2['sum(hadir)'].'</td>
    				<td>'.$row2['sum(tdk_hdr)'].'</td>
    			</tr>
    			
    	';
	    }
	}
	else{
		echo '
    			<tr>
    				<td>Data Tidak Ada </td>
    			</tr>	
    	';
	}
    echo '
    		</tbody>
    		</table>
		<hr><h3>Keterangan Tidak Hadir</h3><br>
		<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
			<thead>
				<tr>
					<th>No</th>
					<th>Rapat</th>
					<th>Koordinator</th>
					<th>Tanggal</th>
					<th>Keterangan</th>
				</tr>
			</thead>
			<tbody>		
    ';
    $no2 = 1;
    $query2 = "SELECT * FROM psdm_koordinator, psdm_rapat, psdm_keterangan WHERE (psdm_rapat.id_koor=psdm_koordinator.id_koor) AND (psdm_keterangan.id_rapat=psdm_rapat.id_rapat) AND (psdm_keterangan.npm = '$npm')";
    $result2 = mysql_query($query2);
    $total_row = mysql_num_rows($result2);
	if ($total_row > 0) {
    while($row2=mysql_fetch_array($result2, MYSQL_ASSOC)){
    	echo '
    			<tr>
    				<td>'.$no2++.'</td>
    				<td>'.$row2['nama_rapat'].'</td>
    				<td>'.$row2['nama_koor'].'</td>
    				<td>'.$row2['tgl'].'</td>
    				<td>'.$row2['ket'].'</td>
    			</tr>
    			
    	';
	    }
	}
	else{
		echo '
    			<tr>
    				<td>Data Tidak Ada </td>
    			</tr>	
    	';
	}    
    echo '
    	</tbody>
    	</table>

    </div';

 ?>