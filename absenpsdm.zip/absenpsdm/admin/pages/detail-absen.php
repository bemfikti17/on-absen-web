<?php 
include "sessions.php";

$npm = $_GET['npm'];
$result = mysql_query("SELECT * FROM anggota, divisi WHERE (anggota.id_divisi=divisi.id_divisi) AND (anggota.npm='$npm')");
$row = mysql_fetch_array($result);
$nama = $row['nama'];
$jabatan = $row['jabatan'];
$divisi = $row['nama_divisi'];

echo '<h1> Rekapan Absen </h1>
<p> nama 	: '.$nama.' <br>
    Jabatan : '.$jabatan .'<br>
    Dep/Bir : '.$divisi .' </p><br>

';

	echo '	
			<table border="1"> 
				<tr>
					<td>No</td>
					<td>Nama Rapat</td>
					<td>Nama Koordinator</td>
					<td>Jumlah Hadir</td>
					<td>Jumlah Tidak Hadir</td>
				</tr>	

	';	
	$no = 1;
    $query2 = "SELECT * FROM psdm_absen, psdm_rapat, psdm_koordinator WHERE (psdm_rapat.id_koor=psdm_koordinator.id_koor) AND (psdm_absen.id_rapat=psdm_rapat.id_rapat) AND (psdm_absen.npm = '$npm')";
    $result2 = mysql_query($query2);
    $total_row = mysql_num_rows($result2);
	if ($total_row > 0) {
    while($row2=mysql_fetch_array($result2, MYSQL_ASSOC)){
    	echo '
    			<tr>
    				<td>'.$no++.'</td>
    				<td>'.$row2['nama_rapat'].'</td>
    				<td>'.$row2['nama_koor'].'</td>
    				<td>'.$row2['jml_hdr'].'</td>
    				<td>'.$row2['jml_tdkhdr'].'</td>
    			</tr>
    			
    	';
	    }
	}
	else{
		echo '
    			<tr>
    				<td>Data Tidak Ada </td>
    			</tr>	
    	';
	}    
    echo '
    		</table>

    ';
    echo '<h3>Keterangan Tidak Hadir</h3>
		<table border="1"> 
				<tr>
					<td>No</td>
					<td>Rapat</td>
					<td>Koordinator</td>
					<td>Tanggal</td>
					<td>Keterangan</td>
				</tr>	
    ';
    $no2 = 1;
    $query2 = "SELECT * FROM psdm_koordinator, psdm_rapat, psdm_keterangan WHERE (psdm_rapat.id_koor=psdm_koordinator.id_koor) AND (psdm_keterangan.id_rapat=psdm_rapat.id_rapat) AND (psdm_keterangan.npm = '$npm')";
    $result2 = mysql_query($query2);
    $total_row = mysql_num_rows($result2);
	if ($total_row > 0) {
    while($row2=mysql_fetch_array($result2, MYSQL_ASSOC)){
    	echo '
    			<tr>
    				<td>'.$no2++.'</td>
    				<td>'.$row2['nama_rapat'].'</td>
    				<td>'.$row2['nama_koor'].'</td>
    				<td>'.$row2['tgl'].'</td>
    				<td>'.$row2['ket'].'</td>
    			</tr>
    			
    	';
	    }
	}
	else{
		echo '
    			<tr>
    				<td>Data Tidak Ada </td>
    			</tr>	
    	';
	}    
    echo '
    		</table>

    ';




 ?>