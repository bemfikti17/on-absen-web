<?php 
	$result = mysql_query("SELECT * FROM anggota, divisi WHERE (anggota.id_divisi=divisi.id_divisi)");

		echo '
			<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
				<thead>
					<tr>	
						<th>No </th>
						<th>Nama </th>
						<th>Jabatan</th>
						<th>Dep/Bir</th>
						<th>Option </th>
					</tr>
				</thead>
				<tbody>	
		';
		$no=1;
		while($row = mysql_fetch_array($result)){	
			
			$npm = $row['npm'];
			$nama = $row['nama'];
			$jabatan = $row['jabatan'];
			$divisi = $row['nama_divisi'];
			echo '
					<tr>
						<td>' . $no++ . ' </td>
						<td>' . $nama . '</td>
						<td>' . $jabatan . '</td>
						<td>' . $divisi . '</td>
						<td> 
							<a href="detail-anggota.php?npm=' . $npm . '"> Detail </a> 								
					</tr>	
			';
		}
		echo '
				</tbody>
			</table>';
	

?>