<?php
include "sessions.php";

$id = $_GET['id'];

$result1=mysql_query("SELECT * FROM psdm_rapat WHERE id_koor='$id'");
while($row1 = mysql_fetch_array($result1)){
$id_rapat=$row1['id_rapat'];

$sql2="DELETE FROM psdm_absen WHERE id_rapat='$id_rapat'";
$query2=mysql_query($sql2);

$sql3="DELETE FROM psdm_keterangan WHERE id_rapat='$id_rapat'";
$query3=mysql_query($sql3);
}

$sql1="DELETE FROM psdm_rapat WHERE id_koor='$id'";
$query1=mysql_query($sql1);

$sql= "DELETE FROM psdm_koordinator WHERE id_koor='$id'";
$query = mysql_query($sql);

header('Location: koor.php');
?>