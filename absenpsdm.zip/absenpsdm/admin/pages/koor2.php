<?php 
	$result = mysql_query("SELECT * FROM psdm_koordinator");

		echo '
				<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
					<thead>
						<tr>	
							<th>No </th>
							<th>Nama Koordinator </th>
							<th>Username</th>
							<th>Password</th>
							<th>Option </th>
						</tr>
					</thead>
					<tbody>
		';
		$no=1;
		while($row = mysql_fetch_array($result)){	
			
			$id_koor = $row['id_koor'];
			$nama_koor = $row['nama_koor'];
			$username = $row['username'];
			$password = $row['password'];
			echo '
				<tr>
					<td>' . $no++ . ' </td>
					<td>' . $nama_koor . '</td>
					<td>' . $username . '</td>
					<td>' . $password . '</td>
					<td align="center"> 
						<a class="btn btn-primary btn-xs" href="edit-koor.php?id=' . $id_koor . '"><i class="fa fa-pencil fa-fw"></i> Edit Data</a>
						<a class="btn btn-danger btn-xs" href="javascript:delete_id(' .$id_koor . ')"><i class="fa fa-minus fa-fw"></i> Hapus Data</a>
				</tr>	
			';
		}
		echo '
		</tbody>
		</table>';
?>