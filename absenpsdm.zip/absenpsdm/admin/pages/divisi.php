<?php 
include "sessions.php";

$result = mysql_query("SELECT sum(psdm_absen.jml_hdr), divisi.nama_divisi FROM divisi, psdm_absen, anggota where (anggota.npm=psdm_absen.npm) and (anggota.id_divisi=divisi.id_divisi) group by anggota.id_divisi");
$result2 = mysql_query("SELECT sum(psdm_rapat.jml_rapat) from psdm_absen , psdm_rapat where psdm")
		echo '
			<table border="1">
				<thead>
					<tr>	
						<th>no</th>
						<th>nama divisi</th>
						<th>jml anggota hadir</th>
					</tr>
				</thead>
				<tbody>	
		';
		$no =1;
		while($row = mysql_fetch_array($result)){	
			$divisi = $row['nama_divisi'];
			$jml_anggota = $row['sum(psdm_absen.jml_hdr)'];
			echo '
					<tr>
						<td>' . $no++ . ' </td>
						<td>' . $divisi . '</td>
						<td>' . $jml_anggota . '</td>
						<td></td>
					</tr>	
			';
		}
		echo '
				</tbody>
			</table>';

 ?>